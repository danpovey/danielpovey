#include <stdio>


int main() {
  // This program takes one argument, the value of N
  // (in N-grams.)  t reads the stdin, e.g.
  // a b c
  // d e
  // and (suppose N=3), 
  // A a 1
  //

}
